library(testthat,quietly=TRUE)


test_check("growfunctions")